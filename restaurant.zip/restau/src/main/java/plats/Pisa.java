package plats;

import Exception.UnavailableDishException;
import Factory.FactoryMeal;
import Factory.FactoryTicket;
import restaurant.Meal;
import restaurant.Ticket;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> plats
 * Date    =====> 22 nov. 2019 
 */
public class Pisa {
	
	private FactoryMeal factm = new FactoryMeal();
	private FactoryTicket factt = new  FactoryTicket();
	private int  nombreFlour;
	private   int nombreMozzarela;
	private int  nombreTomatoes;
	private boolean oliveOil;
	private boolean sall;
	private boolean water;
	
	public Pisa(int nombreF, int nombreT,boolean sall, int nombreM, boolean olive,boolean water) {
		this.nombreFlour = nombreF;
		this.nombreTomatoes = nombreT;
		this.sall = sall;
		this.nombreMozzarela = nombreM;
		this.oliveOil= olive;
		this.water = water;
	}
	
	public Ticket order(String piza) {
		// TODO Auto-generated method stub
		
		int nombre  = Integer.parseInt(piza.substring(0,1));
		String  plat= piza.substring(2, 3);
		if(nombre> this.nombreMozzarela ||  (nombre*4)>this.nombreTomatoes){
		 throw new UnavailableDishException();
		}
		else {					return factt.getInstance(plat,nombre);

		}
	}
	
	public Meal retrieve(Ticket ticket) {
		// TODO Auto-generated method stub
		if(ticket != null)
		return factm.getInstance(ticket);
		return null;
		
	}
	
}
