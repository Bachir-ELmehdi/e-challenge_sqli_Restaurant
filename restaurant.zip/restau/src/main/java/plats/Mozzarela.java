package plats;

import Exception.UnavailableDishException;
import Factory.FactoryMeal;
import Factory.FactoryTicket;
import restaurant.Meal;
import restaurant.Ticket;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> plats
 * Date    =====> 22 nov. 2019 
 */
public class Mozzarela {
	private FactoryMeal factm = new FactoryMeal();
	private FactoryTicket factt = new  FactoryTicket();
	private   int nombreMozzela;
	private int  nombreTomatoes;
	private boolean oliveOil;
	private boolean pepper;
	
	public Mozzarela(int nombreM, int nombreT, boolean olive,boolean pepper) {
		this.nombreMozzela = nombreM;
		this.nombreTomatoes = nombreT;
		this.oliveOil = olive;
		this.pepper = pepper;
	}
	
	public Ticket order(String Mozzarela) {
		// TODO Auto-generated method stub
		
		int nombre  = Integer.parseInt(Mozzarela.substring(0,1));
		String  plat= Mozzarela.substring(2, 3);
		if(nombre> this.nombreMozzela ||  (nombre*2)>this.nombreTomatoes){
		 throw new UnavailableDishException();
		}
		else {
					return factt.getInstance(plat,nombre);

		}
	}
	
	public Meal retrieve(Ticket ticket) {
		// TODO Auto-generated method stub
		if(ticket != null)
		return factm.getInstance(ticket);
		return null;
		
	}

}
