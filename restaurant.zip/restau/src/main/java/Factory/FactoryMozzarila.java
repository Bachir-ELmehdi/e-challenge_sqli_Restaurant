package Factory;

import plats.Mozzarela;


/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> Factory
 * Date    =====> 22 nov. 2019 
 */
public class FactoryMozzarila {
	 

	
	public Mozzarela getInstance(String ...recipes) {
		int nombreMozzela;
	    int nombreTomatoes;
		nombreMozzela = Integer.parseInt(recipes[0].substring(0,1));
		nombreTomatoes = Integer.parseInt(recipes[1].substring(0,2));
		
		return new Mozzarela(nombreMozzela, nombreTomatoes, true, true);
	}

}
