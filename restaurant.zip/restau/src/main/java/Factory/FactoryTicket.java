package Factory;

import restaurant.Ticket;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> Factory
 * Date    =====> 22 nov. 2019 
 */
public class FactoryTicket {
	
	public Ticket getInstance(String plat, int nombre) {
		Ticket ticket =  new Ticket();
		ticket.addTicket(plat, nombre);
		return ticket;
	}

}
