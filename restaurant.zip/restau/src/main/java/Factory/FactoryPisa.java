package Factory;

import plats.Pisa;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> Factory
 * Date    =====> 22 nov. 2019 
 */
public class FactoryPisa {
	
	public Pisa getInstance (String ...recipes) {
		int nombreFlour, nombreMozzarela,nombreTomatoes;
		nombreFlour = Integer.parseInt(recipes[0].substring(0,4));
		nombreTomatoes = Integer.parseInt(recipes[1].substring(0,2));
		nombreMozzarela = Integer.parseInt(recipes[3].substring(0,1));
		
		return new Pisa(nombreFlour, nombreTomatoes, true, nombreMozzarela, true, true);
	}

}
