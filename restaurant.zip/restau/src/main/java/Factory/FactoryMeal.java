package Factory;

import restaurant.Meal;
import restaurant.Ticket;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> Factory
 * Date    =====> 22 nov. 2019 
 */
public class FactoryMeal {
	
	public Meal getInstance(Ticket t) {
		return new Meal(t);
	}

}
