package Exception;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> Exception
 * Date    =====> 22 nov. 2019 
 */
public class UnavailableDishException  extends RuntimeException{

}
