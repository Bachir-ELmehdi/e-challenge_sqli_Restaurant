package restaurant;

import Factory.*;
import plats.Mozzarela;
import plats.Pisa;

import java.util.Arrays;

import Exception.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> restaurant
 * Date    =====> 22 nov. 2019 
 */
public class Restaurant {
	private Mozzarela mozzarela;
	private Pisa pisa;
	private FactoryMeal factm = new FactoryMeal();
	private FactoryTicket factt = new  FactoryTicket();
	private FactoryMozzarila factmo = new  FactoryMozzarila();
	FactoryPisa factp = new FactoryPisa();
	
	/**
	 * @param string4 
	 * @param string3 
	 * @param string2 
	 * @param string 
	 * 
	 */
	public Restaurant(String ...recipes) {
		// TODO Auto-generated constructor stub
		if(recipes.length == 4) {
			mozzarela = factmo.getInstance(recipes);
		}else {
			
			pisa = factp.getInstance(recipes);
		}

	
	}

	/**
	 * @param ticket
	 * @return
	 */
	public Meal retrieve(Ticket ticket) {
		// TODO Auto-generated method stub
		if(mozzarela !=null) {
		return 	mozzarela.retrieve(ticket);
		}
		if(pisa !=null) {
			return pisa.retrieve(ticket);
		}
	return null;
		
	}

	/**
	 * @param string
	 * @return
	 */
	public Ticket order(String plat) {
		// TODO Auto-generated method stub
		
		if(mozzarela != null) {
			return mozzarela.order(plat);
		}
		if(pisa!=null) {
			return pisa.order(plat);
		}
		else
		{
			return null;
			
		}
		
	}
	

}
