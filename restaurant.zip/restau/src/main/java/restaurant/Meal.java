package restaurant;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> restaurant
 * Date    =====> 22 nov. 2019 
 */
public class Meal {
	
	private Ticket ticket;
	
	public Meal(Ticket t) {
		ticket = t;
	}

	/**
	 * @return
	 */
	public int  servedDishes() {
		// TODO Auto-generated method stub
		int nombre=0;
		for(String key : ticket.getCommandes().keySet())
			nombre+= ticket.getCommandes().get(key);
		return nombre;
	}

	/**
	 * @return
	 */
	public String  cookingDuration() {
		// TODO Auto-generated method stub
		int dure =0;
		for(String key : ticket.getCommandes().keySet()) {
			 if(key.equals("P")) {
		      dure += (ticket.getCommandes().get(key)-1)*5;
              dure +=10;  
               }
	        if(key.equals("T")) {
	        			      dure += (ticket.getCommandes().get(key)-1)*3;
	                          dure +=6;   }
	        
		 
		  }
		
		return ""+dure+"" ;
	}

}
