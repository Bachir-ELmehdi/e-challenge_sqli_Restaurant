package restaurant;

import java.util.*;

/**
 * @author =====> BACHIR ELMEHDI
 * Project =====> restau
 * Package =====> restaurant
 * Date    =====> 22 nov. 2019 
 */
public class Ticket {
	private HashMap <String,Integer> commandes;
	/**
	 * 
	 */
	public Ticket( ) {
		// TODO Auto-generated constructor stub
		commandes = new HashMap<String, Integer>();
	}
	
	public void  addTicket(String plat,int nombre) {
		
		commandes.put(plat, nombre);
	}
	
	/**
	 * @return the commandes
	 */
	public HashMap<String, Integer> getCommandes() {
		return commandes;
	}

	/**
	 * @param string
	 * @return
	 */
	public Ticket and(String demande) {
		// TODO Auto-generated method stub
		int nombre = Integer.parseInt(demande.substring(0,1));
		String  plat = demande.substring(2, 3);
		this.addTicket(plat, nombre);
		return this;
	}

}
