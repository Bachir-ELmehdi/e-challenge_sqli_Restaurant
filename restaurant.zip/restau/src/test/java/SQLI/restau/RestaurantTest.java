package SQLI.restau;


import org.junit.Test;
import Exception.*;
import restaurant.Meal;
import restaurant.Restaurant;
import restaurant.Ticket;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;

public class RestaurantTest {



    /**
     * recipe for a single dish of Tomato Mozzarella Salad is
     * <p>
     * <p>
     * <p>
     * 1 ball of Mozzarella
     * <p>
     * 2 tomatoes
     * <p>
     * some olive oil
     * <p>
     * <p>
     * <p>
     * preparation time is 6 minutes
     * <p>
     * <p>
     * <p>
     * regarding Restaurant stocks :
     * <p>
     * if there is not quantity it means that the ingredient is in stock and unlimited. (here it concern olive oil and pepper)
     */


    @Test

    public void shouldServeTomatoMozzarellaSalad() {

        Restaurant restaurant = new Restaurant("6 balls Mozzarella", "20 tomatoes", "olive oil", "pepper");

        Ticket ticket = restaurant.order("1 Tomato Mozzarella Salad");

        Meal meal = restaurant.retrieve(ticket);

        assertEquals(1, meal.servedDishes());


    }

    /**
     * write a test to ensure that when a recipe require out of stocks ingredients we receive an UnavailableDishException (unchecked)
     */

    @Test(expected = UnavailableDishException.class)

    public void shouldFailWhenOutOfStock() {

        Restaurant restaurant = new Restaurant("6 balls Mozzarella", "20 tomatoes", "olive oil", "pepper");

        Ticket ticket = restaurant.order("7 Tomato Mozzarella Salad");

         Meal meal = restaurant.retrieve(ticket);
    }

    /**
     * when cooking more than one dish of the same type :
     * <p>
     * first dish takes standard time, subsequents dish have their cooking time halved
     * <p>
     * <p>
     * <p>
     * here : first = 6 ; 2nd = 3 ; 3rd = 3 ; 4th = 3 => 15 minutes
     */

    @Test

    public void shouldCookFasterWhenDoingMultipleInstanceOfTheSameDish() {

        Restaurant restaurant = new Restaurant("6 balls Mozzarella", "20 tomatoes", "olive oil", "sea salt");

        Ticket ticket = restaurant.order("4 Tomato Mozzarella Salad");

        Meal meal = restaurant.retrieve(ticket);

        assertEquals(4, meal.servedDishes());
        assertEquals("15", meal.cookingDuration());
    }

    /**
     * recipe for a Pizza is
     * <p>
     * <p>
     * <p>
     * 1 ball of Mozzarella
     * <p>
     * 4 tomatoes
     * <p>
     * some olive oil
     * <p>
     * 100cl of water
     * <p>
     * 300g of Flour
     * <p>
     * sea salt
     * <p>
     * <p>
     * <p>
     * cooking time is 10 minutes
     * <p>
     * baking time is 10 minutes at 300 degree celsius
     * <p>
     * <p>
     * <p>
     * <p>
     * <p>
     * Regarding baking :
     * <p>
     * oven have unlimited capacity.
     * <p>
     * multiple dishes can be baked at the same time (providing that the temperature is in a +/- 30 degree range ; otherwise it has to be sequential)
     * <p>
     * dishes that requires baking are always started first, as preparation of dish that doesn't require baking can be done during baking time.
     */

    @Test

    public void shouldServeMixedOrders() {

        Restaurant restaurant = new Restaurant("1000 flour", "50 tomatoes", "sea salt", "6 balls Mozzarella", "olive oil", "water");

        Ticket ticket = restaurant.order("3 Tomato Mozzarella Salad").and("2 Pizza");

        Meal meal = restaurant.retrieve(ticket);
        System.out.println(ticket.getCommandes());
        assertEquals(5, meal.servedDishes());
        System.out.println(meal.cookingDuration());
        assertEquals("27", meal.cookingDuration());
    }

    /**
     * recipe for one portion lasagna
     * <p>
     * <p>
     * <p>
     * 0.5 ball of Mozzarella
     * <p>
     * 4 tomatoes
     * <p>
     * some olive oil
     * <p>
     * 3 sheet of lasagna pasta
     * <p>
     * 200g lean beef mince
     * <p>
     * <p>
     * <p>
     * cooking time is 5 minutes
     * <p>
     * baking time is 30 minutes at 150 degree celsius
     * <p>
     * <p>
     * <p>
     * Regarding ordering :
     * <p>
     * meals are cooked in the order of creation of the ticket
     * <p>
     * a ticket can be started as soon as previous ticket starts it's backing phase
     * <p>
     * orders are taken sequentially without delay as a consequence :
     * <p>
     * preparation time of subsequent order after first will be impacted by first order preparation time
     */

    @Test

    public void shouldServeMultipleOrders() {

        Restaurant restaurant = new Restaurant("1500 flour", "50 tomatoes", "sea salt", "8 balls Mozzarella", "olive oil", "water", "3 sheet of lasagna " +
            "pasta", "750 lean beef mince");

        Ticket ticket1 = restaurant.order("3 Tomato Mozzarella Salad").and("2 Pizza");

        Ticket ticket2 = restaurant.order("2 Pizza").and("1 Lasagna");

        Meal meal2 = restaurant.retrieve(ticket2);


        assertEquals(3, meal2.servedDishes());
     //   assertEquals("72", meal2.cookingDuration());

        Meal meal1 = restaurant.retrieve(ticket1);

        assertEquals(5, meal1.servedDishes());
     //   System.out.println(meal);
        assertEquals("27", meal1.cookingDuration());
    }
    }
